package com.financialplanner.moduleapi.controllers;

import com.financialplanner.moduleapi.security.CallerAccess;
import com.financialplanner.moduleapi.security.CustomUserDetails;
import com.financialplanner.modulecommonbc.exception.ForbiddenOperationException;
import com.financialplanner.modulecommonbc.exception.InvalidCredentialsException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import com.financialplanner.moduleapi.dtos.auth.*;
import com.financialplanner.moduleapi.response.ApiResponse;
import com.financialplanner.moduleapi.response.ApiResponseFactory;
import com.financialplanner.moduleapi.security.JwtService;
import com.financialplanner.moduleauth.application.service.RefreshTokenServiceImpl;
import com.financialplanner.moduleauth.domain.service.AuthService;
import com.financialplanner.moduleauth.domain.service.UserRolesService;
import com.financialplanner.moduleauth.infrastructure.persistence.entity.User;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final RefreshTokenServiceImpl refreshTokenService;
    private final JwtService jwtService;
    private final ApiResponseFactory responseFactory;
    private final UserRolesService userRolesService;

    public AuthController(AuthService authService,
                          RefreshTokenServiceImpl refreshTokenService,
                          JwtService jwtService,
                          ApiResponseFactory responseFactory,
                          UserRolesService userRolesService) {
        this.authService         = authService;
        this.refreshTokenService = refreshTokenService;
        this.jwtService          = jwtService;
        this.responseFactory     = responseFactory;
        this.userRolesService    = userRolesService;
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(@Valid @RequestBody RegisterRequest request) {

        User user = authService.register(request.email(), request.password(), request.first(), request.last());

        var roleNames = userRolesService.getRoleNamesForUser(user.getId());

        var accessToken = jwtService.generateToken(user.getEmail(), Map.of("roles", roleNames));

        var refreshToken = refreshTokenService.createRefreshToken(user.getId());

        var authResponse = new AuthResponse(
            accessToken,
            refreshToken.getToken(),
            user.getId(),
            user.getEmail(),
            user.getUserId(),
            user.getFirst(),
            user.getLast(),
            Set.copyOf(roleNames)
        );

        return ResponseEntity.ok(responseFactory.success(authResponse, "Registration successful"));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest request) {

        User user = authService.login(request.email(), request.password());

        var roleNames = userRolesService.getRoleNamesForUser(user.getId());

        var accessToken = jwtService.generateToken(user.getEmail(), Map.of("roles", roleNames));

        var refreshToken = refreshTokenService.createRefreshToken(user.getId());

        var authResponse = new AuthResponse(
            accessToken,
            refreshToken.getToken(),
            user.getId(),
            user.getEmail(),
            user.getUserId(),
            user.getFirst(),
            user.getLast(),
            Set.copyOf(roleNames)
        );

        return ResponseEntity.ok(responseFactory.success(authResponse, "Login successful"));
    }

    @PostMapping("/refresh")
    public ResponseEntity<ApiResponse<Map<String, String>>> refresh(@RequestBody RefreshTokenRequest request) {

        var refreshToken = refreshTokenService.findByToken(request.refreshToken());
        refreshTokenService.verifyExpiration(refreshToken);

        var user = refreshToken.getUser();

        var roleNames = userRolesService.getRoleNamesForUser(user.getId());

        var newAccessToken = jwtService.generateToken(user.getEmail(), Map.of("roles", roleNames));

        var newRefreshToken = refreshTokenService.createRefreshToken(user.getId());

        var tokens = Map.of(
            "accessToken", newAccessToken,
            "refreshToken", newRefreshToken.getToken()
        );

        return ResponseEntity.ok(responseFactory.success(tokens, "Token refreshed"));
    }

    @PostMapping("/change-password")
    public ResponseEntity<ApiResponse<AuthResponse>> changePassword(
        @Valid @RequestBody ChangePasswordRequest request,
        @AuthenticationPrincipal CustomUserDetails principal) {

        // Only your own password (an admin may change anyone's)
        if (principal == null || principal.getUser() == null) {
            throw new InvalidCredentialsException("Sign in to continue");
        }
        if (!request.id().equals(principal.getUser().getId()) && !CallerAccess.isAdmin(principal)) {
            throw new ForbiddenOperationException("You can only change your own password");
        }

        User user = authService.changePassword(
            request.id(),
            request.currentPassword(),
            request.newPassword()
        );

        var roleNames = userRolesService.getRoleNamesForUser(user.getId());

        var accessToken = jwtService.generateToken(user.getEmail(), Map.of("roles", roleNames));
        var refreshToken = refreshTokenService.createRefreshToken(user.getId());

        var authResponse = new AuthResponse(
            accessToken,
            refreshToken.getToken(),
            user.getId(),
            user.getEmail(),
            user.getUserId(),
            user.getFirst(),
            user.getLast(),
            Set.copyOf(roleNames)
        );

        return ResponseEntity.ok(
            responseFactory.success(authResponse, "Password changed successfully")
        );
    }
}
