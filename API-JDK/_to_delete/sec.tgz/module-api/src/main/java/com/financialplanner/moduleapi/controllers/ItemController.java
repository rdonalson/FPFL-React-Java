package com.financialplanner.moduleapi.controllers;

import com.financialplanner.moduleapi.dtos.item.ItemRequest;
import com.financialplanner.moduleapi.dtos.item.ItemResponse;
import com.financialplanner.moduleapi.mappers.ItemMapper;
import com.financialplanner.moduleapi.response.ApiResponse;
import com.financialplanner.moduleapi.response.ApiResponseFactory;
import com.financialplanner.moduleapi.security.CallerAccess;
import com.financialplanner.moduleapi.security.CustomUserDetails;
import com.financialplanner.moduleitemsbc.domain.service.ItemService;
import com.financialplanner.moduleitemsbc.infrastructure.persistence.entity.Item;
import com.financialplanner.modulecommonbc.exception.ForbiddenOperationException;
import com.financialplanner.modulecommonbc.exception.ItemNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.UUID;

/**
 * REST controller for managing items. Provides endpoints for listing, retrieving,
 * creating, updating, and deleting items.
 * This controller interacts with the service layer for business logic and utilizes
 * a mapper for converting between entities and DTOs.
 * <p>
 * Every endpoint is limited to the signed-in user's own items (admins may see and change anyone's). Someone
 * else's item answers 404, so ids cannot be probed.
 */
@RestController
@RequestMapping("/items")
public class ItemController {

    private final ItemService service;
    private final ItemMapper mapper;
    private final ApiResponseFactory responseFactory;

    /**
     * Constructs a new ItemController to handle API requests for managing items.
     *
     * @param service         the service layer responsible for managing item entities
     * @param mapper          the mapper to convert between entities and DTOs
     * @param responseFactory the factory to build API responses
     */
    public ItemController(ItemService service, ItemMapper mapper, ApiResponseFactory responseFactory) {
        this.service         = service;
        this.mapper          = mapper;
        this.responseFactory = responseFactory;
    }

    /**
     * Retrieves a list of items.
     *
     * @return a ResponseEntity containing an ApiResponse with a list of ItemResponse objects.
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<ItemResponse>>> list(@AuthenticationPrincipal CustomUserDetails principal) {
        // Every user's items: administrators only
        CallerAccess.requireAdmin(principal);
        // Retrieve all time period entities from the repository
        List<Item> items = service.list();
        // Map each entity to its corresponding response object
        List<ItemResponse> responseList = items.stream()
                                               .map(mapper::toResponse)
                                               .toList();
        // Build sanitized ApiResponse using ResponseFactory
        ApiResponse<List<ItemResponse>> response = responseFactory.success(responseList, "Items fetched successfully");
        // Return 200 Success + sanitized body
        return ResponseEntity.ok(response);
    }

    /**
     * Retrieves an item by its unique identifier.
     *
     * @param id the unique identifier of the item to be retrieved
     *
     * @return a {@link ResponseEntity} containing an {@link ApiResponse}
     * that wraps the item's details if retrieval is successful
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ItemResponse>> get(@PathVariable("id") Long id, @AuthenticationPrincipal CustomUserDetails principal) {
        // Retrieve the caller's item
        ItemResponse item = mapper.toResponse(owned(id, principal));
        // Build sanitized ApiResponse using ResponseFactory
        ApiResponse<ItemResponse> body = responseFactory.success(item, "Item " + id + " retrieved successfully");
        // Return 200 Success + sanitized body
        return ResponseEntity.ok(body);
    }

    /**
     * Retrieves a list of items for a given user and item type.
     *
     * @param userId the UUID of the user whose items are to be retrieved
     * @param itemType the ID of the item type to filter the items by
     * @return ResponseEntity containing an ApiResponse with a list of ItemResponse objects
     */
    @GetMapping("/{userId}/{itemType}")
    public ResponseEntity<ApiResponse<List<ItemResponse>>> get(@PathVariable("userId") UUID userId, @PathVariable("itemType") Long itemType,
                                                            @AuthenticationPrincipal CustomUserDetails principal) {
        CallerAccess.requireSelfOrAdmin(userId, principal);
        // Retrieve time period entity from the repository
        List<Item> items = service.findByUserIdAndItemTypeId(userId, itemType);
        // Map each entity to its corresponding response object
        List<ItemResponse> responseList = items.stream()
                                               .map(mapper::toResponse)
                                               .toList();
        // Build sanitized ApiResponse using ResponseFactory
        ApiResponse<List<ItemResponse>> body = responseFactory.success(responseList, "Items retrieved successfully");
        // Return 200 Success + sanitized body
        return ResponseEntity.ok(body);
    }

    /**
     * Creates a new item based on the provided request data.
     * Converts the request data into an entity, persists it,
     * and returns the created item with a location header.
     *
     * @param request the request payload containing item creation details
     *
     * @return ResponseEntity containing the created item in the response body,
     * location of the created item in the headers, and HTTP status 201 (Created)
     */
    @SuppressWarnings({"QodanaXss", "JvmTaintAnalysis", "XSS"})
    @PostMapping
    public ResponseEntity<ApiResponse<ItemResponse>> create(@RequestBody ItemRequest request, @AuthenticationPrincipal CustomUserDetails principal) {
        // Items can only be created for yourself (or by an admin)
        CallerAccess.requireSelfOrAdmin(request.userId(), principal);
        // Convert request → entity & sanitize input
        Item entity = mapper.toEntity(request);
        // Persist entity and then convert & sanitize the response
        ItemResponse response = mapper.toResponse(service.create(entity));
        // Build Location header for 201 Created
        URI location = URI.create("/items/create/" + response.id());
        // Build sanitized ApiResponse using ResponseFactory
        ApiResponse<ItemResponse> body = responseFactory.created(response, "Item created successfully",
                                                                 location.toString());
        // Return 201 Created + Location + sanitized body
        return ResponseEntity.created(location)
                             .body(body);
    }

    /**
     * Updates an existing item with the specified ID based on the provided request body.
     *
     * @param id      The ID of the item to be updated.
     * @param request The request body containing the updated details of the item.
     *
     * @return A {@link ResponseEntity} containing an {@link ApiResponse} with the updated item details
     * as {@link ItemResponse}, and a success message.
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ItemResponse>> update(@PathVariable("id") Long id,
                                                            @RequestBody ItemRequest request,
                                                            @AuthenticationPrincipal CustomUserDetails principal) {
        // The item must be the caller's, and must stay with its owner
        Item existing = owned(id, principal);
        if (!existing.getUserId().equals(request.userId())) {
            throw new ForbiddenOperationException("An item cannot be moved to another user");
        }
        // Convert request → entity & sanitize input
        Item entity = mapper.toEntity(request);
        // Persist entity and then convert & sanitize the response
        ItemResponse response = mapper.toResponse(service.update(id, entity));
        // Build sanitized ApiResponse using ResponseFactory
        ApiResponse<ItemResponse> body = responseFactory.success(response, "Item updated successfully");
        // Return 200 Updated + sanitized body
        return ResponseEntity.ok(body);
    }

    /**
     * Deletes an item identified by the given ID.
     * Upon successful deletion, a response confirming the deletion is returned.
     *
     * @param id the unique identifier of the item to be deleted
     *
     * @return a ResponseEntity containing an ApiResponse with a success message and no data payload
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable("id") Long id, @AuthenticationPrincipal CustomUserDetails principal) {
        owned(id, principal);
        // Build ApiResponse using ResponseFactory
        service.delete(id);
        // Build sanitized ApiResponse using ResponseFactory
        ApiResponse<Void> body = responseFactory.success("Item " + id + " deleted successfully");
        // Return 200 Deleted
        return ResponseEntity.ok(body);
    }

    /** The item with this id if the caller may see it; otherwise 404, the same as an id that does not exist. */
    private Item owned(Long id, CustomUserDetails principal) {
        Item item = service.get(id);
        if (item == null || !CallerAccess.canAccess(item.getUserId(), principal)) {
            throw new ItemNotFoundException("Item " + id + " not found");
        }
        return item;
    }
}
